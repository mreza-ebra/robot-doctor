from launch import LaunchDescription
from launch.substitutions import PathJoinSubstitution
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare


def generate_launch_description():
    return LaunchDescription([
        Node(package="scan_demo", executable="scan_source", name="scan_source",
             parameters=[PathJoinSubstitution([FindPackageShare("scan_demo"), "config", "scan.yaml"])]),
        Node(package="scan_demo", executable="scan_observer", name="scan_observer"),
    ])
