import rclpy
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data
from sensor_msgs.msg import LaserScan


class ScanSource(Node):
    def __init__(self):
        super().__init__("scan_source")
        self.declare_parameter("frame_id", "laser")
        self.publisher = self.create_publisher(LaserScan, "/scan", qos_profile_sensor_data)
        self.timer = self.create_timer(0.5, self.publish_scan)

    def publish_scan(self):
        message = LaserScan()
        message.header.stamp = self.get_clock().now().to_msg()
        message.header.frame_id = self.get_parameter("frame_id").value
        message.angle_min, message.angle_max, message.angle_increment = -0.5, 0.5, 0.5
        message.range_min, message.range_max = 0.1, 10.0
        message.ranges = [1.0, 1.5, 2.0]
        self.publisher.publish(message)


class ScanObserver(Node):
    def __init__(self):
        super().__init__("scan_observer")
        self.subscription = self.create_subscription(
            LaserScan, "/scan", self.receive_scan, qos_profile_sensor_data)

    def receive_scan(self, message):
        self.get_logger().info(f"Received {len(message.ranges)} synthetic ranges")


def run(node_class):
    rclpy.init()
    node = node_class()
    try:
        rclpy.spin(node)
    finally:
        node.destroy_node()
        rclpy.shutdown()


def source_main():
    run(ScanSource)


def observer_main():
    run(ScanObserver)
