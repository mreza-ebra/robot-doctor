from setuptools import setup

setup(name="scan_demo", version="0.1.0", packages=["scan_demo"],
      data_files=[("share/ament_index/resource_index/packages", ["resource/scan_demo"]),
                  ("share/scan_demo", ["package.xml"]),
                  ("share/scan_demo/launch", ["launch/scan.launch.py"]),
                  ("share/scan_demo/config", ["config/scan.yaml"])],
      entry_points={"console_scripts": ["scan_source = scan_demo.nodes:source_main",
                                         "scan_observer = scan_demo.nodes:observer_main"]})
