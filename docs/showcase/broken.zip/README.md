# Controlled ROS 2 scan example

This synthetic project publishes and observes /scan. It is not a real sensor,
navigation stack, or customer incident. The example uses the product license.

The broken version intentionally refers to config/missing.yaml in
scan_demo/launch/scan.launch.py. The supplied file is config/scan.yaml.
The corrected version changes only that reference. Run robot-doctor-scan .
to reproduce the static result. No ROS installation is needed for that scan.

Static verification does not establish build success or runtime behavior.
To test ROS execution separately in a sourced ROS 2 environment:
colcon build --symlink-install
source install/setup.bash
ros2 launch scan_demo scan.launch.py
ros2 topic echo /scan --once
No ROS execution or hardware compatibility is claimed by this example.
